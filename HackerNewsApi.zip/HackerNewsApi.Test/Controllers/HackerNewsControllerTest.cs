﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using HackerNewsApi.Controllers;
using HackerNews.Service;
using HackerNews.Models;

namespace HackerNewsApi.Test.Controllers
{
    public class HackerNewsControllerTest
    {
        private Mock<ILogger<HackerNewsController>> _mockLogger;
        private Mock<IHackerNewsService> _mockHackerNewsService;
        private HackerNewsController _hackerNewsController;

        public HackerNewsControllerTest() 
        {
            _mockLogger = new Mock<ILogger<HackerNewsController>>();
            _mockHackerNewsService= new Mock<IHackerNewsService>();

            _hackerNewsController = new HackerNewsController(_mockLogger.Object, _mockHackerNewsService.Object);
        }

        [Fact]
        public async Task Get_All_TopStories_Success()
        {
            _mockHackerNewsService.Setup(x => x.GetHackerNews()).Returns(Task.FromResult(GetHackerList()));
            var resut=await _hackerNewsController.Get();
            Assert.NotNull(resut);
            Assert.Equal(3, resut.Count);
        }

        [Fact]
        public async Task Get_All_TopStories_NoContent()
        {
            List<Hacker> hackerList = null;
            _mockHackerNewsService.Setup(x => x.GetHackerNews()).Returns(Task.FromResult(hackerList));
            var resut = await _hackerNewsController.Get();
            Assert.Null(resut);
        }

        private List<Hacker> GetHackerList()
        {
            return new List<Hacker>()
            {
                new Hacker()
                {
                    id= 1,
                    title="test1",
                    url="www.test1.com"
                },
                new Hacker()
                {
                    id= 2,
                    title="test2",
                    url="www.test2.com"
                },
                new Hacker()
                {
                    id= 3,
                    title="test3",
                    url="www.test3.com"
                }
            };
        }
    }
}
