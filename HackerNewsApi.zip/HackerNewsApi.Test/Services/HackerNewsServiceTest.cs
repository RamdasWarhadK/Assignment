﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using HackerNews.Models;
using HackerNews.Service;
using Moq;
using Moq.EntityFrameworkCore;
using Moq.Protected;
using RichardSzalay.MockHttp;
using Xunit;

namespace HackerNewsApi.Test.Services
{
    public class HackerNewsServiceTest
    {
        private Mock<IHackerNewsService> _mockHackerNewsService;
        private HackerNewsService _hackerNewsService;
        public HackerNewsServiceTest() 
        {
            _mockHackerNewsService= new Mock<IHackerNewsService>();
        }

        [Fact]
        public async Task GetHackerNewsIds_Success()
        {
            var mockHttp = new Mock<HttpMessageHandler>();

            var mockedProtected = mockHttp.Protected();
            var setupApiRequest = mockedProtected.Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>()
                );
            var apiMockedResponse =
                setupApiRequest.ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent("[234234,234234,5435435,2312312,123123,442444]")
                });
            _mockHackerNewsService.Setup(x => x.GetHackerNewsIds()).Returns(Task.FromResult(GetIdList()));
            _hackerNewsService=new HackerNewsService();
            var result = await _hackerNewsService.GetHackerNewsIds();
            Assert.NotNull(result);
        }

        [Fact]
        public async Task GetHackerNews_Success()
        {
            var mockHttp = new Mock<HttpMessageHandler>();

            var mockedProtected = mockHttp.Protected();
            var setupApiRequest = mockedProtected.Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>()
                );
            var apiMockedResponse =
                setupApiRequest.ReturnsAsync(new HttpResponseMessage()
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent("[234234,234234,5435435,2312312,123123,442444]")
                });
            _mockHackerNewsService.Setup(x => x.GetHackerNewsIds()).Returns(Task.FromResult(GetIdList()));

            _mockHackerNewsService.Setup(x => x.GetHackerNews()).Returns(Task.FromResult(GetHackerList()));

            _hackerNewsService = new HackerNewsService();
            var result = await _hackerNewsService.GetHackerNewsIds();
            Assert.NotNull(result);
        }


        private List<int> GetIdList()
        {
            return new List<int> { 234234, 234234, 5435435, 2312312, 123123, 442444 };
        }

        private List<Hacker> GetHackerList()
        {
            return new List<Hacker>()
            {
                new Hacker()
                {
                    id= 1,
                    title="test1",
                    url="www.test1.com"
                },
                new Hacker()
                {
                    id= 2,
                    title="test2",
                    url="www.test2.com"
                },
                new Hacker()
                {
                    id= 3,
                    title="test3",
                    url="www.test3.com"
                }
            };
        }
    }
}
