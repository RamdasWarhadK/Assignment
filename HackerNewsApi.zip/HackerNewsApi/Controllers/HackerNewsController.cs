using HackerNews.Models;
using HackerNews.Service;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching;
using Microsoft.Extensions.Caching.Memory;

namespace HackerNewsApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HackerNewsController : ControllerBase
    {
        private readonly ILogger<HackerNewsController> _logger;
        private readonly IHackerNewsService _hackerNewsService;
        private readonly IMemoryCache _memoryCache;

        public HackerNewsController(ILogger<HackerNewsController> logger, IHackerNewsService hackerNewsService, IMemoryCache memoryCache)
        {
            _logger = logger;
            _hackerNewsService = hackerNewsService;
            _memoryCache = memoryCache;
        }

        [EnableCors("_myAllowSpecificOrigins")]
        [HttpGet]
        public async Task<IEnumerable<Hacker>> Get()
        {
            var cacheData = _memoryCache.Get<IEnumerable<Hacker>>("hackers");
            if (cacheData != null)
            {
                return cacheData;
            }

            var expirationTime = DateTimeOffset.Now.AddMinutes(5.0);
            cacheData = await _hackerNewsService.GetHackerNews();
            _memoryCache.Set("hackers", cacheData, expirationTime);
            return cacheData;
        }
    }
}