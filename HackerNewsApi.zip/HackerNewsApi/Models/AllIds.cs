﻿namespace HackerNews.Models
{
    public class AllIds
    {
        public List<int> AllIdsArray { get; set; }
    }
}
