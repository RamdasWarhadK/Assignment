﻿using HackerNews.Models;
using System.Text.Json;

namespace HackerNews.Service
{
    public class HackerNewsService : IHackerNewsService
    {
        public async Task<List<int>> GetHackerNewsIds()
        {
            List<int> topstoryIdList = new List<int>();
            using (var client = new HttpClient())
            {
                var request = new HttpRequestMessage(HttpMethod.Get, "https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty");
                var response = await client.SendAsync(request);
                response.EnsureSuccessStatusCode();
                var data= await response.Content.ReadAsStringAsync();
                topstoryIdList = JsonSerializer.Deserialize<List<int>>(data);
            }
            return topstoryIdList;
        }

        public async Task<List<Hacker>> GetHackerNews()
        {
            List<int> topstoryIdList = await GetHackerNewsIds();
            List<Hacker> hackerList = new List<Hacker>();
            int cot = 1;
            foreach (int topstoryId in topstoryIdList)
            {
                using (var client = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Get, $"https://hacker-news.firebaseio.com/v0/item/{topstoryId}.json?print=pretty");
                    var response = await client.SendAsync(request);
                    response.EnsureSuccessStatusCode();
                    Console.WriteLine(await response.Content.ReadAsStringAsync());
                    var result = await response.Content.ReadAsStringAsync();
                    Hacker hacker= JsonSerializer.Deserialize<Hacker>(result);
                    if (!string.IsNullOrEmpty(hacker.url))
                    {
                        hacker.srno = cot;
                        hackerList.Add(hacker);
                        cot++;
                    }
                } 
            }
            return hackerList;
        }
    }
}
