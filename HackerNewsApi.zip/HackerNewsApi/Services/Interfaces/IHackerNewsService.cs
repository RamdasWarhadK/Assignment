﻿using HackerNews.Models;

namespace HackerNews.Service
{
    public interface IHackerNewsService
    {
        Task<List<Hacker>>  GetHackerNews();
        Task<List<int>> GetHackerNewsIds();
    }
}
